#define EXTRA_NAME "@bivalue."
#include "loadbmp.h"

#define threshold 128
#define Point(x,y) lpPoints[(x)+(y)*nWidth]

void BiValue()
{
	BYTE *lpPoints=new BYTE[nWidth*nHeight];
	GetPoints(lpPoints);
	int x,y;
	for(y=0;y<nHeight;y++)
	{
		for(x=0;x<nWidth;x++)
		{
			if (Point(x,y)>(BYTE)threshold) Point(x,y)=255;
			else Point(x,y)=0;
		}
	}

	PutPoints(lpPoints);
	delete lpPoints;
}

void main(int argc, char *argv[])
{
	if(argc==2)
		FileName=argv[1];
	else
		return;	
	OpenFile();
	BiValue();
	SaveAs();
}