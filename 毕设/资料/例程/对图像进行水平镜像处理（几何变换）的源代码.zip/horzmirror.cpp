#define EXTRA_NAME "@hormirror."
#include "loadbmp.h"

void HorzMirror()
{
	int x,y;
	BYTE *lpTemp=new BYTE[nByteWidth*nHeight];
	for(y=0;y<nHeight;y++)
	{
		for(x=0;x<nWidth;x++)
		{
			lpTemp[x*3+y*nByteWidth]=lpBits[(nWidth-1-x)*3+y*nByteWidth];
			lpTemp[x*3+1+y*nByteWidth]=lpBits[(nWidth-1-x)*3+1+y*nByteWidth];
			lpTemp[x*3+2+y*nByteWidth]=lpBits[(nWidth-1-x)*3+2+y*nByteWidth];
		}
	}
	lpBits=lpTemp;
}

void main(int argc, char *argv[])
{
	if(argc==2)
		FileName=argv[1];
	else
		return;	
	OpenFile();
	HorzMirror();
	SaveAs();
}