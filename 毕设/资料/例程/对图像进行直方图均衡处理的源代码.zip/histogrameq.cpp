#define EXTRA_NAME "@histogrameq."
#include "loadbmp.h"

#define Point(x,y) lpPoints[(x)+(y)*nWidth]

void HistogramEq()
{
	int x,y;
	BYTE *lpPoints=new BYTE[nWidth*nHeight];
	GetPoints(lpPoints);	
	int r[256],s[256];
	ZeroMemory(r,1024);
	ZeroMemory(s,1024);
	for(y=0;y<nHeight;y++)
	{
		for(x=0;x<nWidth;x++)
		{
			r[Point(x,y)]++;
		}
	}
	s[0]=r[0];
	for(y=1;y<256;y++)
	{
		s[y]=s[y-1];
		s[y]+=r[y];
	}
	for(y=0;y<nHeight;y++){
		for(x=0;x<nWidth;x++)
		{
			Point(x,y)=s[Point(x,y)]*255/nWidth/nHeight;
		}
	}
	PutPoints(lpPoints);
	delete lpPoints;
}

void main(int argc, char *argv[])
{
	if(argc==2)
		FileName=argv[1];
	else
		return;	
	OpenFile();
	HistogramEq();
	SaveAs();
}