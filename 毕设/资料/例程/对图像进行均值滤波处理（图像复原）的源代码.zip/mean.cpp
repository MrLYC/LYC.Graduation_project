#define EXTRA_NAME "@meansmooth."
#include "loadbmp.h"

void Mean()
{
	int x,y,x1,y1,p;
	int sr,sg,sb;
	BYTE *lpTemp=new BYTE[nByteWidth*nHeight];
	for(y=1;y<nHeight-1;y++)
	{
		for(x=1;x<nWidth-1;x++)
		{
			p=x*3+y*nByteWidth;
			sb=0;
			sg=0;
			sr=0;
			for(y1=-1;y1<=1;y1++)
			for(x1=-1;x1<=1;x1++)
			{
				sb+=lpBits[(y+y1)*nByteWidth+(x+x1)*3];
				sg+=lpBits[(y+y1)*nByteWidth+(x+x1)*3+1];
				sr+=lpBits[(y+y1)*nByteWidth+(x+x1)*3+2];
			}
			lpTemp[p+2]=sr/9;
			lpTemp[p+1]=sg/9;
			lpTemp[p]=sb/9;
		}
	}
	lpBits=lpTemp;
}

void main(int argc, char *argv[])
{
	if(argc==2)
		FileName=argv[1];
	else
		return;	
	OpenFile();
	Mean();
	SaveAs();
}