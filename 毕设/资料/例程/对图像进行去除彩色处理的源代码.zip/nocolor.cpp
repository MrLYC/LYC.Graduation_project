#define EXTRA_NAME "@nocolor."
#include "loadbmp.h"

void NoColor()
{
	if (lpBitmap==0) return;
	int x,y,p;
	BYTE Point;
	for(y=0;y<nHeight;y++)
		for(x=0;x<nWidth;x++)
		{
			p=x*3+y*nByteWidth;
			Point=(BYTE)(0.299*(float)lpBits[p+2]+0.587*(float)lpBits[p+1]+0.114*(float)lpBits[p]+0.1);
			lpBits[p+2]=Point;
			lpBits[p+1]=Point;
			lpBits[p]=Point;
		}
}

void main(int argc, char *argv[])
{
	if(argc==2)
		FileName=argv[1];
	else
		return;	
	OpenFile();
	NoColor();
	SaveAs();
}