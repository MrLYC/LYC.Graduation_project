#define EXTRA_NAME "@medsmooth."
#include "loadbmp.h"

void Med()
{
	int x,y;
	BYTE p[9],s;
	BYTE *lpTemp=new BYTE[nByteWidth*nHeight];
	int i,j;
	for(y=1;y<nHeight-1;y++)
	{
		for(x=3;x<nWidth*3-3;x++)
		{
			p[0]=lpBits[x-3+(y-1)*nByteWidth];
			p[1]=lpBits[x+(y-1)*nByteWidth];
			p[2]=lpBits[x+3+(y-1)*nByteWidth];
			p[3]=lpBits[x-3+y*nByteWidth];
			p[4]=lpBits[x+y*nByteWidth];
			p[5]=lpBits[x+3+y*nByteWidth];
			p[6]=lpBits[x-3+(y+1)*nByteWidth];
			p[7]=lpBits[x+(y+1)*nByteWidth];
			p[8]=lpBits[x+3+(y+1)*nByteWidth];
			for(j=0;j<5;j++)
			{
				for(i=j+1;i<9;i++)
				{
					if (p[j]>p[i])
					{
						s=p[j];
						p[j]=p[i];
						p[i]=s;
					}
				}
			}
			lpTemp[x+y*nByteWidth]=p[4];
		}
	}
	lpBits=lpTemp;
}

void main(int argc, char *argv[])
{
	if(argc==2)
		FileName=argv[1];
	else
		return;	
	OpenFile();
	Med();
	SaveAs();
}