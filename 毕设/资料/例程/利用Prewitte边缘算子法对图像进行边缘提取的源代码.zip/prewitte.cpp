#define EXTRA_NAME "@prewitteedge."
#include "loadbmp.h"

#define Point(x,y) lpPoints[(x)+(y)*nWidth]
#define Point1(x,y) lpPoints1[(x)+(y)*nWidth]

void Prewitte()
{
	int x,y,x1,y1,i;
	BYTE *lpPoints=new BYTE[nWidth*nHeight];
	BYTE *lpPoints1=new BYTE[nWidth*nHeight];
	memset(lpPoints1,0,nWidth*nHeight);
	GetPoints(lpPoints);

	int d,max;
	static s[8][9]={
		{-1,-1,-1,0,0,0,1,1,1},
		{0,-1,-1,1,0,-1,1,1,0},
		{1,0,-1,1,0,-1,1,0,-1},
		{1,1,0,1,0,-1,0,-1,-1},
		{1,1,1,0,0,0,-1,-1,-1},
		{0,1,1,-1,0,1,-1,-1,0},
		{-1,0,1,-1,0,1,-1,0,1},
		{-1,-1,0,-1,0,1,0,1,1}
	};
	for(y=1;y<nHeight-1;y++)
	{
		for(x=1;x<nWidth-1;x++)
		{
			max=0;
			for(i=0;i<8;i++)
			{
				d=0;
				for(y1=0;y1<3;y1++)
				for(x1=0;x1<3;x1++)
				{
					d+=s[i][x1+y1*3]*Point(x+x1-1,y+y1-1);
				}
				if (d>max) max=d;
			}
			if (max>255) max=255;
			Point1(x,y)=(BYTE)max;
		}
	}
	PutPoints(lpPoints1);
	delete lpPoints;
	delete lpPoints1;
}

void main(int argc, char *argv[])
{
	if(argc==2)
		FileName=argv[1];
	else
		return;	
	OpenFile();
	Prewitte();
	SaveAs();
}