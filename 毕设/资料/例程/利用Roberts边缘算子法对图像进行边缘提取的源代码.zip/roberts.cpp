#define EXTRA_NAME "@robertsedge."
#include "loadbmp.h"

#define Point(x,y) lpPoints[(x)+(y)*nWidth]
#define Point1(x,y) lpPoints1[(x)+(y)*nWidth]

void Roberts()
{
	int x,y;
	BYTE *lpPoints=new BYTE[nWidth*nHeight];
	BYTE *lpPoints1=new BYTE[nWidth*nHeight];
	memset(lpPoints1,0,nWidth*nHeight);
	GetPoints(lpPoints);

	int d;
	for(y=0;y<nHeight-1;y++)
	{
		for(x=0;x<nWidth-1;x++)
		{
			d=2*(abs(Point(x,y)-Point(x+1,y+1))+abs(Point(x+1,y)-Point(x,y+1)));
			if (d>255) d=255;
			Point1(x,y)=(BYTE)d;
		}
	}
	PutPoints(lpPoints1);
	delete lpPoints;
	delete lpPoints1;
}

void main(int argc, char *argv[])
{
	if(argc==2)
		FileName=argv[1];
	else
		return;	
	OpenFile();
	Roberts();
	SaveAs();
}